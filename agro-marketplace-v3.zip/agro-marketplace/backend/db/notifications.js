const { v4: uuidv4 } = require("uuid");
const { query } = require("./pool");
const { rowToCamel, rowsToCamel } = require("./mappers");

/**
 * Create a notification row. This is currently the in-app record only -
 * connect email/SMS delivery (see README) to actually reach the user
 * outside the app.
 */
async function create({ userId, type, payload }) {
  const { rows } = await query(
    `INSERT INTO notifications (id, user_id, type, payload) VALUES ($1,$2,$3,$4) RETURNING *`,
    [uuidv4(), userId, type, payload || {}]
  );
  return rowToCamel(rows[0]);
}

async function findForUser(userId, limit = 100) {
  const { rows } = await query(
    `SELECT * FROM notifications WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2`,
    [userId, limit]
  );
  return rowsToCamel(rows);
}

async function findById(id) {
  const { rows } = await query(`SELECT * FROM notifications WHERE id = $1`, [id]);
  return rowToCamel(rows[0]);
}

async function markRead(id) {
  const { rows } = await query(`UPDATE notifications SET read_at = now() WHERE id = $1 RETURNING *`, [id]);
  return rowToCamel(rows[0]);
}

module.exports = { create, findForUser, findById, markRead };
