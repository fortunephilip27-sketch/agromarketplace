const { query } = require("./pool");
const { rowToCamel, rowsToCamel, buildSetClause } = require("./mappers");

const UPDATABLE_FIELDS = [
  "name", "description", "category", "unitPrice", "unit",
  "quantityAvailable", "originCountry", "status", "imageUrl",
];

async function create(product) {
  const { rows } = await query(
    `INSERT INTO products (
       id, seller_id, name, description, category, unit_price, unit,
       quantity_available, origin_country, image_url, status
     ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
     RETURNING *`,
    [
      product.id, product.sellerId, product.name, product.description, product.category,
      product.unitPrice, product.unit, product.quantityAvailable, product.originCountry,
      product.imageUrl || null, product.status || "active",
    ]
  );
  return rowToCamel(rows[0]);
}

async function findById(id) {
  const { rows } = await query(`SELECT * FROM products WHERE id = $1`, [id]);
  return rowToCamel(rows[0]);
}

/**
 * Public catalog listing with optional filters. Always restricted to
 * status = 'active' - use findBySeller() for a seller's full listing set.
 */
async function listActive({ category, search, minPrice, maxPrice, sellerId } = {}) {
  const conditions = [`status = 'active'`];
  const values = [];
  let i = 1;

  if (category) { conditions.push(`category = $${i++}`); values.push(category); }
  if (sellerId) { conditions.push(`seller_id = $${i++}`); values.push(sellerId); }
  if (minPrice) { conditions.push(`unit_price >= $${i++}`); values.push(parseFloat(minPrice)); }
  if (maxPrice) { conditions.push(`unit_price <= $${i++}`); values.push(parseFloat(maxPrice)); }
  if (search) {
    conditions.push(`(name ILIKE $${i} OR description ILIKE $${i})`);
    values.push(`%${search}%`);
    i += 1;
  }

  const { rows } = await query(
    `SELECT * FROM products WHERE ${conditions.join(" AND ")} ORDER BY created_at DESC`,
    values
  );
  return rowsToCamel(rows);
}

/** All products regardless of status - for admin counts/listings only. */
async function listAll() {
  const { rows } = await query(`SELECT * FROM products ORDER BY created_at DESC`);
  return rowsToCamel(rows);
}

async function findBySeller(sellerId) {
  const { rows } = await query(
    `SELECT * FROM products WHERE seller_id = $1 ORDER BY created_at DESC`,
    [sellerId]
  );
  return rowsToCamel(rows);
}

async function updateById(id, updates) {
  const { setParts, values } = buildSetClause(updates, UPDATABLE_FIELDS, 1);
  if (setParts.length === 0) return findById(id);
  values.push(id);
  const { rows } = await query(
    `UPDATE products SET ${setParts.join(", ")}, updated_at = now() WHERE id = $${values.length} RETURNING *`,
    values
  );
  return rowToCamel(rows[0]);
}

async function deleteById(id) {
  const { rowCount } = await query(`DELETE FROM products WHERE id = $1`, [id]);
  return rowCount > 0;
}

/**
 * Atomically reserve stock for an order line item. Runs the check and the
 * decrement in one SQL statement so two simultaneous buyers can't both
 * "win" the last unit (an inherent race condition in the old JSON-file
 * read-modify-write pattern this replaces). Returns null if there wasn't
 * enough stock left, without throwing - the caller decides how to respond.
 */
async function reserveStock(client, productId, quantity) {
  const { rows } = await client.query(
    `UPDATE products
     SET quantity_available = quantity_available - $2,
         status = CASE WHEN quantity_available - $2 <= 0 THEN 'out_of_stock' ELSE status END,
         updated_at = now()
     WHERE id = $1 AND status = 'active' AND quantity_available >= $2
     RETURNING *`,
    [productId, quantity]
  );
  return rowToCamel(rows[0]);
}

module.exports = { create, findById, listActive, listAll, findBySeller, updateById, deleteById, reserveStock };
