const { query } = require("./pool");
const { rowToCamel, rowsToCamel } = require("./mappers");

async function create(q) {
  const { rows } = await query(
    `INSERT INTO quotes (
       id, quote_number, buyer_id, seller_id, product_id, product_name, quantity,
       destination_country, destination_city, packaging, frequency, message, status
     ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,'open')
     RETURNING *`,
    [
      q.id, q.quoteNumber, q.buyerId, q.sellerId, q.productId, q.productName, q.quantity,
      q.destinationCountry, q.destinationCity || null, q.packaging || null,
      q.frequency || "one_time", q.message || null,
    ]
  );
  return withOffers(rowToCamel(rows[0]));
}

async function findById(id) {
  const { rows } = await query(`SELECT * FROM quotes WHERE id = $1`, [id]);
  if (!rows[0]) return null;
  return withOffers(rowToCamel(rows[0]));
}

async function findForUser(userId) {
  const { rows } = await query(
    `SELECT * FROM quotes WHERE buyer_id = $1 OR seller_id = $1 ORDER BY created_at DESC`,
    [userId]
  );
  const quotes = rowsToCamel(rows);
  const withAllOffers = [];
  for (const q of quotes) withAllOffers.push(await withOffers(q));
  return withAllOffers;
}

async function listAll() {
  const { rows } = await query(`SELECT * FROM quotes ORDER BY created_at DESC`);
  const quotes = rowsToCamel(rows);
  const withAllOffers = [];
  for (const q of quotes) withAllOffers.push(await withOffers(q));
  return withAllOffers;
}

async function addOffer(quoteId, offer) {
  await query(
    `INSERT INTO quote_offers (id, quote_id, unit_price, currency, shipping_price, valid_until, message)
     VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [
      offer.id, quoteId, offer.unitPrice, offer.currency || "USD",
      offer.shippingPrice || 0, offer.validUntil || null, offer.message || null,
    ]
  );
  await query(`UPDATE quotes SET status = 'offered' WHERE id = $1`, [quoteId]);
  return findById(quoteId);
}

async function updateStatus(id, status) {
  const { rows } = await query(`UPDATE quotes SET status = $2 WHERE id = $1 RETURNING *`, [id, status]);
  if (!rows[0]) return null;
  return withOffers(rowToCamel(rows[0]));
}

async function withOffers(quote) {
  const { rows } = await query(
    `SELECT * FROM quote_offers WHERE quote_id = $1 ORDER BY created_at ASC`,
    [quote.id]
  );
  return { ...quote, offers: rowsToCamel(rows) };
}

module.exports = { create, findById, findForUser, listAll, addOffer, updateStatus };
