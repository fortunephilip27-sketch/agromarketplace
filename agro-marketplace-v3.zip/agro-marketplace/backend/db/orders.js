const { query, withTransaction } = require("./pool");
const { rowToCamel, rowsToCamel, buildSetClause } = require("./mappers");
const products = require("./products");

const UPDATABLE_ORDER_FIELDS = [
  "status", "paymentProofUrl", "trackingInfo", "statusHistory", "flwTxRef", "flwTransactionId",
  "cryptoPayment", "paymentReference", "paymentVerifiedBy", "paymentVerifiedAt",
  "refundStatus", "refundAmount", "disputeReason", "disputeRaisedBy",
  "disputeResolution", "disputeResolvedAt", "disputeResolvedBy",
];
const JSONB_ORDER_FIELDS = new Set(["trackingInfo", "statusHistory", "cryptoPayment"]);

function generateOrderNumber() {
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `AGM-${Date.now().toString().slice(-6)}-${rand}`;
}

/**
 * Create an order and its line items in a single transaction, reserving
 * stock for each line item atomically as we go. If any line item can't be
 * fulfilled (product gone, insufficient stock), the whole transaction is
 * rolled back - no partial orders, no oversold stock.
 *
 * `items` here is the array of { product, quantity, breakdown } already
 * validated and priced by the route (see routes/orders.js), so this
 * function focuses purely on persistence + stock reservation.
 */
async function createWithLineItems({ id, buyerId, shippingAddress, paymentMethod, currency, lineItems }) {
  return withTransaction(async (client) => {
    const orderTotal = round2(lineItems.reduce((s, li) => s + li.totalChargedToBuyer, 0));
    const platformRevenueTotal = round2(lineItems.reduce((s, li) => s + li.platformRevenue, 0));
    const orderNumber = generateOrderNumber();
    const statusHistory = [{ status: "pending_payment", at: new Date().toISOString() }];

    const { rows: orderRows } = await client.query(
      `INSERT INTO orders (
         id, order_number, buyer_id, shipping_address, payment_method, currency,
         order_total, platform_revenue_total, status, status_history
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'pending_payment',$9)
       RETURNING *`,
      [id, orderNumber, buyerId, shippingAddress, paymentMethod, currency, orderTotal, platformRevenueTotal, JSON.stringify(statusHistory)]
    );

    const insertedLineItems = [];
    for (const li of lineItems) {
      // Reserve stock atomically; throws (aborting the transaction) if unavailable.
      const reserved = await products.reserveStock(client, li.productId, li.quantity);
      if (!reserved) {
        throw new InsufficientStockError(li.productName);
      }

      const { rows } = await client.query(
        `INSERT INTO order_line_items (
           id, order_id, product_id, seller_id, product_name, unit_price, unit, quantity,
           subtotal, buyer_service_fee, total_charged_to_buyer, seller_commission,
           seller_payout, platform_revenue, buyer_service_fee_percent, seller_commission_percent
         ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)
         RETURNING *`,
        [
          li.id, id, li.productId, li.sellerId, li.productName, li.unitPrice, li.unit, li.quantity,
          li.subtotal, li.buyerServiceFee, li.totalChargedToBuyer, li.sellerCommission,
          li.sellerPayout, li.platformRevenue, li.buyerServiceFeePercent, li.sellerCommissionPercent,
        ]
      );
      insertedLineItems.push(rowToCamel(rows[0]));
    }

    return { ...rowToCamel(orderRows[0]), lineItems: insertedLineItems };
  });
}

class InsufficientStockError extends Error {
  constructor(productName) {
    super(`Not enough stock available for ${productName}.`);
    this.name = "InsufficientStockError";
  }
}

async function findById(id) {
  const { rows } = await query(`SELECT * FROM orders WHERE id = $1`, [id]);
  if (!rows[0]) return null;
  const order = rowToCamel(rows[0]);
  order.lineItems = await lineItemsForOrder(id);
  return order;
}

async function findByFlwTxRef(txRef) {
  const { rows } = await query(`SELECT * FROM orders WHERE flw_tx_ref = $1`, [txRef]);
  if (!rows[0]) return null;
  const order = rowToCamel(rows[0]);
  order.lineItems = await lineItemsForOrder(order.id);
  return order;
}

async function lineItemsForOrder(orderId) {
  const { rows } = await query(
    `SELECT * FROM order_line_items WHERE order_id = $1 ORDER BY created_at ASC`,
    [orderId]
  );
  return rowsToCamel(rows);
}

async function findByBuyer(buyerId) {
  const { rows } = await query(
    `SELECT * FROM orders WHERE buyer_id = $1 ORDER BY created_at DESC`,
    [buyerId]
  );
  const orders = rowsToCamel(rows);
  for (const o of orders) o.lineItems = await lineItemsForOrder(o.id);
  return orders;
}

/** Orders containing at least one line item sold by this seller, with lineItems filtered to just theirs. */
async function findBySeller(sellerId) {
  const { rows } = await query(
    `SELECT DISTINCT o.* FROM orders o
     JOIN order_line_items li ON li.order_id = o.id
     WHERE li.seller_id = $1
     ORDER BY o.created_at DESC`,
    [sellerId]
  );
  const orders = rowsToCamel(rows);
  for (const o of orders) {
    const { rows: liRows } = await query(
      `SELECT * FROM order_line_items WHERE order_id = $1 AND seller_id = $2 ORDER BY created_at ASC`,
      [o.id, sellerId]
    );
    o.lineItems = rowsToCamel(liRows);
  }
  return orders;
}

async function listAll() {
  const { rows } = await query(`SELECT * FROM orders ORDER BY created_at DESC`);
  const orders = rowsToCamel(rows);
  for (const o of orders) o.lineItems = await lineItemsForOrder(o.id);
  return orders;
}

async function updateById(id, updates) {
  const preparedUpdates = { ...updates };
  for (const field of JSONB_ORDER_FIELDS) {
    if (preparedUpdates[field] !== undefined) {
      preparedUpdates[field] = JSON.stringify(preparedUpdates[field]);
    }
  }
  const { setParts, values } = buildSetClause(preparedUpdates, UPDATABLE_ORDER_FIELDS, 1);
  if (setParts.length === 0) return findById(id);
  values.push(id);
  const { rows } = await query(
    `UPDATE orders SET ${setParts.join(", ")}, updated_at = now() WHERE id = $${values.length} RETURNING *`,
    values
  );
  if (!rows[0]) return null;
  const order = rowToCamel(rows[0]);
  order.lineItems = await lineItemsForOrder(id);
  return order;
}

/** Append one entry to an order's status_history JSONB array and return the updated order. */
async function appendStatusHistory(id, entry) {
  const order = await findById(id);
  if (!order) return null;
  const history = [...(order.statusHistory || []), entry];
  return updateById(id, { statusHistory: history });
}

function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

module.exports = {
  createWithLineItems, findById, findByFlwTxRef, findByBuyer, findBySeller, listAll,
  updateById, appendStatusHistory, lineItemsForOrder, InsufficientStockError,
};
