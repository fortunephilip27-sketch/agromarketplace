const { query } = require("./pool");
const { rowToCamel, rowsToCamel } = require("./mappers");

async function create({ id, senderId, receiverId, message }) {
  const { rows } = await query(
    `INSERT INTO messages (id, sender_id, receiver_id, message) VALUES ($1,$2,$3,$4) RETURNING *`,
    [id, senderId, receiverId, message]
  );
  return rowToCamel(rows[0]);
}

async function findConversation(userIdA, userIdB) {
  const { rows } = await query(
    `SELECT * FROM messages
     WHERE (sender_id = $1 AND receiver_id = $2) OR (sender_id = $2 AND receiver_id = $1)
     ORDER BY created_at ASC`,
    [userIdA, userIdB]
  );
  return rowsToCamel(rows);
}

async function findById(id) {
  const { rows } = await query(`SELECT * FROM messages WHERE id = $1`, [id]);
  return rowToCamel(rows[0]);
}

async function markRead(id) {
  const { rows } = await query(`UPDATE messages SET read_at = now() WHERE id = $1 RETURNING *`, [id]);
  return rowToCamel(rows[0]);
}

module.exports = { create, findConversation, findById, markRead };
