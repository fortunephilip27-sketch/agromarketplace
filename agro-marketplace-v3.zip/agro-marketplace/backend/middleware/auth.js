const jwt = require('jsonwebtoken');
function requireAuth(req,res,next){const header=req.headers.authorization||'';const token=header.startsWith('Bearer ')?header.slice(7):null;if(!token)return res.status(401).json({error:'Missing or invalid authorization header.'});try{req.user=jwt.verify(token,process.env.JWT_SECRET);next()}catch(e){return res.status(401).json({error:'Invalid or expired token.'})}}
function requireRole(...roles){return (req,res,next)=>{if(!req.user||!roles.includes(req.user.role))return res.status(403).json({error:`This action requires one of these roles: ${roles.join(', ')}.`});next()}}
module.exports={requireAuth,requireRole};
